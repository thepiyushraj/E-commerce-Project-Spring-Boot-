package com.ecommerce.app.config;
 
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
 
import org.springframework.stereotype.Component;
 
import java.security.Key;
import java.util.Date;
 
@Component
public class JwtUtil {
 
	private final Key key = Keys.hmacShaKeyFor("mySecretKeymySecretKeymySecretKey12".getBytes());
 
	public String generateToken(String userId, String role) {
 
		return Jwts.builder().setSubject(userId).claim("role", role).setIssuedAt(new Date())
				.setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60))
				.signWith(key, SignatureAlgorithm.HS256).compact();
	}
 
	private Claims extractClaims(String token) {
 
		return Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody();
	}
 
	public String getUserId(String token) {
		return extractClaims(token).getSubject();
	}
 
	public String getRole(String token) {
		return (String) extractClaims(token).get("role");
	}
 
	public boolean isTokenExpired(String token) {
		return extractClaims(token).getExpiration().before(new Date());
	}
 
	public boolean validateToken(String token) {
 
		try {
			return !isTokenExpired(token);
		} catch (Exception e) {
			return false;
		}
	}
} 