package com.ecommerce.app.controller;

import com.ecommerce.app.entity.Cart;
import com.ecommerce.app.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cart")
@CrossOrigin("*")
public class CartController {

    @Autowired
    private CartService service;
    
    // add to cart
    @PostMapping
    public Cart addToCart(@RequestBody Cart cart) {
        return service.addToCart(cart);
    }
    
   // get by user id
    @GetMapping("/{userId}")
    public List<Cart> getCart(@PathVariable Long userId) {
        return service.getCartDetails(userId);
    }

   // Get all cart items
    @GetMapping
    public List<Cart> getAllCartItems() {
        return service.getAllCartItems();
    }

    // Update cart item
    @PutMapping("/{cartId}")
    public Cart updateCart(@PathVariable Long cartId, @RequestBody Cart cart) {
        return service.updateCart(cartId, cart);
    }
    
   // Remove item
    @DeleteMapping("/{cartId}")
    public String removeItem(@PathVariable Long cartId) {
        service.removeFromCart(cartId);
        return "Item removed from cart";
    }
    
    
//
//   //Clear all cart (ADMIN only)
//   @DeleteMapping
//   public String clearAllCart() {
//     service.clearCart();
//     return "All cart data cleared";
// }

}

