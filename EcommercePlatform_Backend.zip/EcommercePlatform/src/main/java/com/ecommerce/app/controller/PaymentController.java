package com.ecommerce.app.controller;

import com.ecommerce.app.entity.Payment;
import com.ecommerce.app.service.PaymentService;
import com.stripe.exception.StripeException;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/payment")
@CrossOrigin(origins = "*")//used to connect frontend and backend
@Tag(name = "Payment APIs")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @Operation(summary = "Create Stripe Checkout Session")
    @PostMapping("/create-checkout-session/{orderId}")
    public ResponseEntity<Map<String, Object>> createCheckoutSession(
            @PathVariable Long orderId
    ) throws StripeException {

        Long amount = (long) paymentService.getOrderAmount(orderId);

        SessionCreateParams params =
                SessionCreateParams.builder()

                        .addPaymentMethodType(
                                SessionCreateParams.PaymentMethodType.CARD
                        )

                        .setMode(SessionCreateParams.Mode.PAYMENT)

                        .setSuccessUrl(
                        	    "http://localhost:5500/success.html?session_id={CHECKOUT_SESSION_ID}&orderId=" + orderId
                        	)

                        .setCancelUrl(
                        	    "http://localhost:5500/cancel.html"
                        	)

                        .addLineItem(
                                SessionCreateParams.LineItem.builder()
                                        .setQuantity(1L)

                                        .setPriceData(
                                                SessionCreateParams.LineItem.PriceData.builder()
                                                        .setCurrency("usd")
                                                        .setUnitAmount(amount * 100)

                                                        .setProductData(
                                                                SessionCreateParams.LineItem.PriceData.ProductData.builder()
                                                                        .setName("Order Payment")
                                                                        .build()
                                                        )
                                                        .build()
                                        )
                                        .build()
                        )
                        .build();

        Session session = Session.create(params);

        Map<String, Object> responseData = new HashMap<>();

        responseData.put("sessionId", session.getId());//A unique tracking ID that Stripe generated for this specific checkout attempt.
        responseData.put("url", session.getUrl());

        return ResponseEntity.ok(responseData);
    }

    @Operation(summary = "Verify Stripe Payment")
    @GetMapping("/verify/{orderId}/{sessionId}")
    public ResponseEntity<Map<String, Object>> verifyPayment(
            @PathVariable Long orderId,
            @PathVariable String sessionId
    ) throws StripeException {

        Payment payment = paymentService
                .verifyAndProcessPayment(orderId, sessionId);

        Map<String, Object> response = new HashMap<>();

        response.put("message", "Payment Successful");
        response.put("paymentId", payment.getPaymentId());
        response.put("status", payment.getPaymentStatus());
        response.put("transactionId", payment.getTransactionId());

        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Get Payment By ID")
    @GetMapping("/{paymentId}")
    public Payment getPaymentById(@PathVariable Long paymentId) {
        return paymentService.getPaymentById(paymentId);
    }

    @Operation(summary = "Get All Payments")
    @GetMapping("/all")
    public List<Payment> getAllPayments() {
        return paymentService.getAllPayments();
    }

    @Operation(summary = "Get Payment By Order")
    @GetMapping("/order/{orderId}")
    public Payment getPaymentByOrder(@PathVariable Long orderId) {
        return paymentService.getPaymentByOrder(orderId);
    }

    @Operation(summary = "Refund Payment")
    @PostMapping("/refund/{paymentId}")
    public Payment refundPayment(@PathVariable Long paymentId) {
        return paymentService.refundPayment(paymentId);
    }
}